import 'package:flutter/material.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Image.asset("assets/images/fogpifkalologo.png"),
          SizedBox(height: 80),
          Text(
            "Üdvözöllek!",
            style: TextStyle(color: Colors.white, fontSize: 24),
          ),
          SizedBox(height: 30),
          ElevatedButton.icon(
            onPressed: () {},
            style: ElevatedButton.styleFrom(
              foregroundColor: Colors.white,
              backgroundColor: Colors.transparent,
            ),
            icon: Icon(Icons.arrow_right_alt),
            label: Text("Tovább a bejelentkezéshez"),
          ),
        ],
      ),
    );
  }
}
