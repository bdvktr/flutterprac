import 'package:flutter/material.dart';
import 'package:flutterquiz/models/quiz_question.dart';

const questions = [
  QuizQuestion("What are the main building blocks of Flutter UI's?", [
    "Widgets",
    "Components",
    "Blocks",
    "Functions",
  ]),
  QuizQuestion("How are Flutter UI's built?", [
    "By combining widgets in code",
    "By combining functions in code",
    "By combining components in code",
    "By combining blocks in code",
  ]),
  QuizQuestion("What/'s the purpose of StatefulWidget", [
    "To build dynamic and interactive UI's",
    "To build static UI's",
    "To build functions",
    "To build blocks",
  ]),
  QuizQuestion(
    "Which widget should you try to use more often: StatelessWidget or StateFulWidget?",
    [
      "StatelessWidget",
      "StatefulWidget",
      "Both are equally used",
      "Neither are used",
    ],
  ),
  QuizQuestion("What happens if you change data in StatelessWidget?", [
    "Nothing, because StatelessWidgets are immutable",
    "The widget rebuilds",
    "The app crashes",
    "The data changes",
  ]),
  QuizQuestion("How should you update data inside of StatefulWidget", [
    "By calling setState()",
    "By changing the data directly",
    "By rebuilding the widget",
    "By calling update()",
  ]),
];
