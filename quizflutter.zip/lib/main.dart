import 'package:flutter/material.dart';
import 'package:flutterquiz/quiz.dart';
import 'package:flutterquiz/start_screen.dart';


void main() {
  runApp(Quiz());
}
